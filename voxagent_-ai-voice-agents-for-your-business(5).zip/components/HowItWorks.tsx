import React from 'react';

const StepCard: React.FC<{
  step: string;
  title: string;
  description: string;
  icon: React.ReactNode;
}> = ({ step, title, description, icon }) => (
  <div className="relative p-px rounded-xl bg-gradient-to-br from-gray-200 to-gray-200 transition-all duration-300 hover:from-brand-purple hover:to-brand-fuchsia">
    <div className="bg-white h-full p-8 rounded-[11px] flex flex-col items-center text-center">
      <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-gradient-to-br from-brand-purple to-brand-fuchsia text-white rounded-full text-xl font-bold">
        {step}
      </div>
      <h3 className="mt-4 text-xl font-bold text-brand-dark-text">{title}</h3>
      <p className="mt-2 text-brand-gray-text">{description}</p>
      <div className="mt-6 flex-grow flex items-center justify-center">
        {icon}
      </div>
    </div>
  </div>
);

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-20 md:py-32 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-extrabold text-brand-dark-text">
            Insanely <span className="bg-gradient-to-r from-brand-purple to-brand-fuchsia text-transparent bg-clip-text">simple</span> to get started
          </h2>
          <p className="mt-4 text-lg text-brand-gray-text max-w-2xl mx-auto">Create and launch your AI phone agent in three simple steps to optimize your call management and make sure you don't miss any opportunity anymore !</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 md:gap-12">
          <StepCard
            step="1"
            title="Describe your business"
            description="Provide essential details like your name, services, opening hours, and specific rules for your agent."
            icon={
              <svg className="w-20 h-20 text-brand-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
            }
          />
          <StepCard
            step="2"
            title="Generate your AI agent"
            description="Our AI learns everything from your info and website to build a custom-trained agent just for you."
            icon={
                <svg className="w-20 h-20 text-brand-purple" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8V4H8" />
                    <rect width="16" height="12" x="4" y="8" rx="2" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2 14h2" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M20 14h2" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 13v2" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 13v2" />
                </svg>
            }
          />
          <StepCard
            step="3"
            title="Go live & receive calls"
            description="Get your dedicated phone number. Your agent is now live, handling calls and updating your systems 24/7."
            icon={
              <svg className="w-20 h-20 text-brand-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
            }
          />
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
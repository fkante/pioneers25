import React from 'react';

const TranscriptLine: React.FC<{ speaker: 'Caller' | 'Agent'; children: React.ReactNode }> = ({ speaker, children }) => {
  const isAgent = speaker === 'Agent';
  return (
    <p className="text-brand-gray-text">
      <span className={`font-semibold ${isAgent ? 'text-brand-purple' : 'text-brand-dark-text'}`}>
        {speaker}:
      </span>{' '}
      {children}
    </p>
  );
};

const DemoCard: React.FC<{ title: string, scenario: React.ReactNode }> = ({ title, scenario }) => (
  <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
    <div className="p-4 bg-gray-50 border-b border-gray-200 flex items-center space-x-3">
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
            <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
        </div>
        <h4 className="font-bold text-brand-dark-text">{title}</h4>
    </div>
    <div className="p-6 space-y-3">
      {scenario}
    </div>
  </div>
);

const LiveExamples: React.FC = () => {
  return (
    <section id="examples" className="py-20 md:py-32 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-extrabold text-brand-dark-text">
            See it in <span className="bg-gradient-to-r from-brand-purple to-brand-fuchsia text-transparent bg-clip-text">action</span>
          </h2>
          <p className="mt-4 text-lg text-brand-gray-text max-w-2xl mx-auto">Actual examples from businesses that use VoxAgent every day.</p>
        </div>
        <div className="grid lg:grid-cols-3 gap-8">
          <DemoCard 
            title="Restaurant Booking"
            scenario={
              <>
                <TranscriptLine speaker="Caller">Hi, I'd like to book a table for 2 tonight.</TranscriptLine>
                <TranscriptLine speaker="Agent">Of course! What time would you prefer?</TranscriptLine>
                <TranscriptLine speaker="Caller">Around 8pm please.</TranscriptLine>
                <TranscriptLine speaker="Agent">Perfect. I have a table for two at 8pm. Can I get a name for the booking?</TranscriptLine>
                <TranscriptLine speaker="Caller">It's for Sarah.</TranscriptLine>
                <TranscriptLine speaker="Agent">Great, Sarah. You're all set for tonight at 8pm. We look forward to seeing you!</TranscriptLine>
              </>
            }
          />
          <DemoCard 
            title="Garage Repair"
            scenario={
              <>
                <TranscriptLine speaker="Caller">My car is making a weird rattling noise.</TranscriptLine>
                <TranscriptLine speaker="Agent">I can help with that. Is the noise more from the engine or underneath the car?</TranscriptLine>
                <TranscriptLine speaker="Caller">I think it's the engine. Can I bring it in tomorrow?</TranscriptLine>
                <TranscriptLine speaker="Agent">Yes, we have an opening at 10am or 2pm. Which works better for you?</TranscriptLine>
                <TranscriptLine speaker="Caller">10am is perfect.</TranscriptLine>
                <TranscriptLine speaker="Agent">Booked in. We'll see you and your car tomorrow at 10am.</TranscriptLine>
              </>
            }
          />
          <DemoCard 
            title="Medical Appointment"
            scenario={
              <>
                <TranscriptLine speaker="Caller">I need to schedule my annual check-up.</TranscriptLine>
                <TranscriptLine speaker="Agent">Certainly. Dr. Evans is available next Tuesday and Thursday. Do you have a preference?</TranscriptLine>
                <TranscriptLine speaker="Caller">Tuesday morning would be best.</TranscriptLine>
                <TranscriptLine speaker="Agent">We have a 9:30am slot available. Shall I book that for you?</TranscriptLine>
                <TranscriptLine speaker="Caller">Yes, please.</TranscriptLine>
                <TranscriptLine speaker="Agent">You're confirmed for Tuesday at 9:30am. You'll receive a reminder text the day before.</TranscriptLine>
              </>
            }
          />
        </div>
      </div>
    </section>
  );
};

export default LiveExamples;
import React from 'react';

const FeatureItem: React.FC<{ icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ icon, title, children }) => {
  return (
    <div className="flex items-start space-x-4">
      <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-gradient-to-br from-brand-purple to-brand-fuchsia text-white rounded-lg">
        {icon}
      </div>
      <div>
        <h3 className="text-lg font-semibold text-brand-dark-text">{title}</h3>
        <p className="mt-1 text-brand-gray-text">{children}</p>
      </div>
    </div>
  );
};

const Features: React.FC = () => {
  return (
    <section id="features" className="py-20 md:py-32 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold text-brand-dark-text">Everything you need, nothing you don't.</h2>
          <p className="mt-4 text-lg text-brand-gray-text max-w-2xl mx-auto">Powerful features designed for simplicity and performance.</p>
        </div>
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
          <FeatureItem
            title="No-Code Agent Generator"
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path></svg>}
          >
            Our intuitive interface lets you build and launch your agent in minutes.
          </FeatureItem>
          <FeatureItem
            title="Phone Number Included"
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>}
          >
            Get a new local number or port your existing one. It's your choice.
          </FeatureItem>
          <FeatureItem
            title="Real-time Reservations"
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>}
          >
            Agents book appointments directly into your calendar system instantly.
          </FeatureItem>
          <FeatureItem
            title="Knowledge Extraction"
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>}
          >
            Point to your website, and the AI will automatically learn about your business.
          </FeatureItem>
          <FeatureItem
            title="CRM & Calendar Integrations"
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path></svg>}
          >
            Connect to Google Calendar, Notion, Salesforce, and more.
          </FeatureItem>
          <FeatureItem
            title="Multilingual Support"
            icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5h12M9 3v2m4.28 10.28a11.957 11.957 0 01-8.56 0M12 21V11M3 11a9 9 0 0118 0v10M12 3a9 9 0 015.657 15.657"></path></svg>}
          >
            Serve a diverse customer base with agents that speak multiple languages.
          </FeatureItem>
        </div>
      </div>
    </section>
  );
};

export default Features;
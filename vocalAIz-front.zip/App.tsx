import React, { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import HowItWorks from './components/HowItWorks';
import UseCases from './components/UseCases';
import LiveExamples from './components/LiveExamples';
import Features from './components/Features';
import CallToAction from './components/CallToAction';
import Pricing from './components/Pricing';
import FAQ from './components/FAQ';
import Footer from './components/Footer';

const App: React.FC = () => {
  useEffect(() => {
    const animatedElements = document.querySelectorAll('[data-animate-on-scroll]');
    
    if (animatedElements.length > 0 && 'IntersectionObserver' in window) {
      const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
            entry.target.classList.remove('opacity-0');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.1 });

      animatedElements.forEach(el => {
        el.classList.add('opacity-0');
        observer.observe(el);
      });
      
      document.querySelectorAll('[data-stagger-children]').forEach(container => {
        const children = container.querySelectorAll('[data-animate-on-scroll]');
        children.forEach((child, index) => {
            (child as HTMLElement).style.animationDelay = `${index * 150}ms`;
        });
      });

      return () => observer.disconnect();
    } else if (animatedElements.length > 0) {
      // Fallback for older browsers
      animatedElements.forEach(el => {
        el.classList.add('animate-fade-in-up');
        el.classList.remove('opacity-0');
      });
    }
  }, []);

  return (
    <div className="bg-brand-light-bg font-sans antialiased">
      <Header />
      <main>
        <Hero />
        <HowItWorks />
        <UseCases />
        <LiveExamples />
        <Features />
        <CallToAction />
        <Pricing />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
};

export default App;
import React from 'react';

const CallToAction: React.FC = () => {
  return (
    <section id="cta" className="py-12 md:py-20 bg-brand-light-bg">
      <div className="container mx-auto px-6">
        <div>
          <div className="bg-gradient-to-r from-brand-purple to-brand-fuchsia p-px rounded-2xl shadow-[10px_10px_40px_-10px_rgba(124,58,237,0.6)]">
            <div className="relative bg-brand-light-bg rounded-[15px] p-10 md:p-16 text-center overflow-hidden">
              <div className="relative z-0">
                <h2 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-brand-dark-text tracking-tight">
                  Experience Roboto AI instantly
                </h2>
                <p className="mt-4 text-lg text-brand-gray-text max-w-2xl mx-auto">
                  Join hundreds of businesses revolutionizing their customer service. Get started in minutes.
                </p>
                <div className="mt-10">
                  <button 
                    className="bg-gradient-to-r from-brand-purple to-brand-fuchsia text-white font-bold py-4 px-8 rounded-lg shadow-lg shadow-brand-purple/20 hover:shadow-brand-purple/40"
                  >
                    Create an agent
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;